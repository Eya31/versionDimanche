package tn.SGII_Ville.model.enums;
public enum PrioriteType {
    URGENTE,
    PLANIFIEE
}