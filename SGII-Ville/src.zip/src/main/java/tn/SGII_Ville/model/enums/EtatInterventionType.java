package tn.SGII_Ville.model.enums;
public enum EtatInterventionType {
    EN_ATTENTE,
    EN_COURS,
    SUSPENDUE,
    TERMINEE
}