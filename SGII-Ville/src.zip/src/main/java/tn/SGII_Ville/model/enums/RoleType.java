package tn.SGII_Ville.model.enums;

public enum RoleType {
    CITOYEN,
    TECHNICIEN,
    CHEF_SERVICE,
    ADMINISTRATEUR
}