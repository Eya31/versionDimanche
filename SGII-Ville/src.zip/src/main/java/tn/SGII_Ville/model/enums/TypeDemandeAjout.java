package tn.SGII_Ville.model.enums;

public enum TypeDemandeAjout {
    EQUIPEMENT,
    RESSOURCE
}