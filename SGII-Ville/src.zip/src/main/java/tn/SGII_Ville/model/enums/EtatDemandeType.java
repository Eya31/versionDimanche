package tn.SGII_Ville.model.enums;
public enum EtatDemandeType {
    SOUMISE,
    EN_ATTENTE,
    TRAITEE,
    REJETEE
}