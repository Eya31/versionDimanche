package tn.SGII_Ville.model.enums;
public enum EtatEquipementType {
    FONCTIONNEL,
    DEFECTUEUX,
    EN_MAINTENANCE
}
