package tn.SGII_Ville.model.enums;

public enum EtatDemandeAjoutType {
    EN_ATTENTE_ADMIN,
    ACCEPTEE,
    REFUSEE
}