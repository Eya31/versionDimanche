export interface AffecterMainDOeuvreRequest {
  ouvrierIds: number[];
  interventionId?: number;
}

